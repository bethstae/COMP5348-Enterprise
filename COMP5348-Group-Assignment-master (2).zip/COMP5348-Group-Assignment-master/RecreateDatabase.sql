create database Bookstore;
create database Bank;
create database DeliveryCo;
