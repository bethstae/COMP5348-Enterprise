# COMP5348-Group-Assignment

Before running the program, ensure that **message queue** is installed and enabled on Windows 7 or later.

The program was built using **Visual Studio 2017**.

## To run the program:
  1. Create databases for BookStore, DeliveryCo and Bank
  2. Run their respective sql scripts
  3. Start BookStore.WebClient.Process, BookStore.Process, Bank.Process, DeliveryCo.process and Email.process
  
**Please make sure to log off and log in each time the program is restarted**
  
 
