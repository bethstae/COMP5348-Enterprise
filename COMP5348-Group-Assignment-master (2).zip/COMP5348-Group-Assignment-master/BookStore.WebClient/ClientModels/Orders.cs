using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BookStore.Services.MessageTypes;

namespace BookStore.WebClient.ClientModels
{
    /*public class Orders
    {
        public List<Order> Orders = new List<Order>();
        //public IList<Order> Orders { get { return mOrder.AsReadOnly(); } }
        public IUserProvider UserProvider
        {
            get { return ServiceLocator.Current.GetInstance<IUserProvider>(); }
        }


        public List<Order> GetOrders(User pUser)
        {
            Orders = ServiceFactory.Instance.OrderService.GetOrders(pUser);
        }

        public void RefundOrder(Orders pOrder)
        {
            ServiceFactory.Instance.OrderService.CancelOrder(pOrder);
        }

    }*/
}