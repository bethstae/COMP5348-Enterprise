delete from Bank.dbo.Accounts;
delete from Bank.dbo.Customers;

delete from BookStore.dbo.UserRole;
delete from BookStore.dbo.Users;
delete from BookStore.dbo.Deliveries;
delete from BookStore.dbo.Orders;
delete from BookStore.dbo.OrderItems;
delete from BookStore.dbo.Books;
delete from BookStore.dbo.Stocks;
delete from BookStore.dbo.LoginCredentials;
delete from BookStore.dbo.Roles;

delete from DeliveryCo.dbo.DeliveryInfo