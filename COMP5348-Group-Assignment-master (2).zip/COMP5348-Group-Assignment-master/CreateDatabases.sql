drop database Bank;
drop database DeliveryCo;
drop database BookStore;
create database Bank;
create database DeliveryCo;
create database BookStore;