select * from stocks
select * from Books
select * from Orders
select * from Users
select * from Bank.dbo.Accounts
select * from DeliveryCo.dbo.DeliveryInfo

drop database videos
create database videos
drop database Deliveries
create database Deliveries
